#include <stdio.h>

int main() {
	printf("Hello World\n"); 
  printf("Welcome to CSE 31!\n"); 
  return 0; 
 }