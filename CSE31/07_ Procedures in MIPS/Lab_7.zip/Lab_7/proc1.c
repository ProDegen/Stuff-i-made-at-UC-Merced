
#include <stdio.h>
#include <stdlib.h>

int sum(int x, int y){
    return (x+y);
}

int main(){
int m = 10,n = 5;
int r = sum(m, n);
printf("%d", r);
return 0;

}

