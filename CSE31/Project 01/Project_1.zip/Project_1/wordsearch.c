#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Declarations of the two functions you will implement
// Feel free to declare any helper functions or global variables
void printPuzzle(char** arr);
void searchPuzzle(char** arr, char* word);
int bSize;
int** fArr;
int wordSize = 0;
int wordNum = 0;
int isFound = 0;

// Main function, DO NOT MODIFY 	
int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <puzzle file name>\n", argv[0]);
        return 2;
    }
    int i, j;
    FILE *fptr;

    // Open file for reading puzzle
    fptr = fopen(argv[1], "r");
    if (fptr == NULL) {
        printf("Cannot Open Puzzle File!\n");
        return 0;
    }

    // Read the size of the puzzle block
    fscanf(fptr, "%d\n", &bSize);
    
    // Allocate space for the puzzle block and the word to be searched
    char **block = (char**)malloc(bSize * sizeof(char*));
    char *word = (char*)malloc(20 * sizeof(char));

    // Read puzzle block into 2D arrays
    for(i = 0; i < bSize; i++) {
        *(block + i) = (char*)malloc(bSize * sizeof(char));
        for (j = 0; j < bSize - 1; ++j) {
            fscanf(fptr, "%c ", *(block + i) + j);            
        }
        fscanf(fptr, "%c \n", *(block + i) + j);
    }
    fclose(fptr);

    printf("Enter the word to search: ");
    scanf("%s", word);
    
    // Print out original puzzle grid
    printf("\nPrinting puzzle before search:\n");
    printPuzzle(block);
    
    // Call searchPuzzle to the word in the puzzle
    searchPuzzle(block, word);
    
    return 0;
}

void printPuzzle(char** arr) {
	// This function will print out the complete puzzle grid (arr). 
    // It must produce the output in the SAME format as the samples 
    // in the instructions.
    // Your implementation here...
    for(int i = 0; i < bSize; i++){
        for(int j = 0; j < bSize; j++){
            printf("%c ", *(*(arr + i) + j));
        }
        printf("\n");
    }
    printf("\n");
}
// made a 2nd one to print 2d int arrays
void printIntPuzzle(int** arr){
    for(int i = 0; i < bSize; i++){
        for(int j = 0; j < bSize; j++){
            printf("%d ", *(*(arr + i) + j));
        }
        printf("\n\n");
    }
   
}
//making a function to recursivlet check for letters, a little different from
//what i would do normally but if i did it the way i wanted it would be super long
//so this is just so it doesnt take like 3 pages to write

int puzzleLoop(char** cArr, char* word, int row, int col){

    wordSize = strlen(word);
    //this loop is for checking if its the first char of the string
    if (wordNum == 0){
        for (int i = 0; i < bSize; i++){
            for (int j = 0;  j < bSize; j++){
                //checks if char is the first in str
                if (*(*(cArr + i) + j) == *(word + wordNum)){
                    wordNum++;
                    //using some recursion, without this my actualy code would be huge
                    if ((puzzleLoop(cArr, word, i, j)) != -1){
                        *(*(fArr + i) + j) = *(*(fArr + i) + j) * 10 + wordNum;
                        wordNum--;
                        isFound = 1;
                    }
                } 
            }
        }
    }
    //this loop if it isnt the first char
    else {
        for (int i = (row - 1); i <= (row + 1); i++) {
            for (int j = (col - 1);  j <= (col + 1); j++) {
                if (wordNum >= wordSize){
                    return 1;
                }
                //long spaghetti code to check if the val around our char are actually in the array
                if (i >= 0 && i < bSize && j >= 0 && j < bSize && !(i == row && j == col)) {
                    if (*(*(cArr + i) + j) == *(word + wordNum)) {
                        wordNum++;
                        //after this, this chuck is just a copy of our previous bit
                        if ((puzzleLoop(cArr, word, i, j)) != -1) {
                            *(*(fArr + i) + j) = *(*(fArr + i) + j) * 10 + wordNum;
                            wordNum--;
                            return 1;
                        }
                        
                    }
                }  
            }
        }
    }
    // If the function passes all the way through without finding any letters that it is looking for, it subtracts from wordNum to look for another pathway, then returns a -1 to fail the previous recursive if statement to keep looking.
    wordNum--;
    return -1;
}
void searchPuzzle(char** arr, char* word) {
    // This function checks if arr contains the search word. If the 
    // word appears in arr, it will print out a message and the path 
    // as shown in the sample runs. If not found, it will print a 
    // different message as shown in the sample runs.
    // Your implementation here...
    fArr = (int**)malloc(bSize * sizeof(int*));
    for (int i = 0; i < bSize; i++){
		*(fArr + i) = (int*)malloc(bSize * sizeof(int));
		for(int j = 0; j < bSize; j++){
			*(*(fArr + i) + j) = 0;
		}
	}
    //this checks if the words are lower case and makes them upper by subtracting 32
    for (int i = 0; i < strlen(word); i++){
        if (*(word + i) >= 'a' && *(word + i) <= 'z'){
            *(word + i) = *(word + i) - 32;
        }
    }
    puzzleLoop(arr,word,0,0);

    if(isFound == 1){
        printf("Word Found!\n");
        printf("Priunting the search path: \n");
        printIntPuzzle(fArr);
    }
    else{
        printf("Word not Found! \n");
    }
}
