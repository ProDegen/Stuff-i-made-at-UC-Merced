from logic import TruthTable;

myTable = TruthTable(['a', 'b'], ['a and -b']);
myTable.display();

myTable = TruthTable(['a', 'b','c'], ['(a and -b) or -c']);
myTable.display();