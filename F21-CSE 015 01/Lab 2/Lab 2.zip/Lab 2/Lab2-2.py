from logic import TruthTable;
print("Modus Ponens: ");
myTable = TruthTable(['p', 'q'], ['(p -> q)','((p -> q) and p)','((p -> q) and p) -> q']);
myTable.display();

print("Modus Tollens: ");
myTable = TruthTable(['p', 'q'], ['(p -> q)' ,'(-q and (p -> q))','(-q and (p -> q)) -> -p']);
myTable.display();

print("Hypothetical Syllogism: ");
myTable = TruthTable(['p', 'q','r'], ['(p -> q)','(q -> r)','(p -> r)', '((p -> q) and (q -> r)) -> (p -> r)']);
myTable.display();

print("Disjunctive Syllogism: ");
myTable = TruthTable(['p','q'], ['(p or q)', '((p or q) and -p)','((p or q) and -p) -> q']);
myTable.display();

print("Addition: ");
myTable = TruthTable(['p','q'], ['(p or q)', 'p -> (p or q)']);
myTable.display();

print("Simplification: ");
myTable = TruthTable(['p','q'], ['(p and q)', '(p and q) -> p']);
myTable.display();

print("Conjunction: ");
myTable = TruthTable(['p','q'], ['((p) and (q))', '(p and q)', '((p) and (q)) -> (p and q)']);
myTable.display();

print("Resolution: ");
myTable = TruthTable(['p','q','r'], ['(p or q)', '(-p or r)','(q or r)','((p or q) and (-p or r)) -> (q or r)']);
myTable.display();