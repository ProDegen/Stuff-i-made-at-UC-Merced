from logic import TruthTable;

myTable = TruthTable(['p', 'q'], ['p and q']);
myTable.display();